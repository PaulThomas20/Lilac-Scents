Lilac Scents - Site Package

Files included:
- index.html             -> Main website file. Open in a browser to run locally.
- assets/images/         -> Placeholder images (hero + 4 products).
- assets/videos/         -> Folder for your video files (sample readme; add MP4/WebM here).
- README.txt             -> This file.

Admin panel:
- URL: open the site (index.html) and click the Admin button.
- Username: admin
- Password: lilac123

Quick admin instructions (in-site Help tab also contains these):
- Theme Editor: pick Primary/Secondary colors and upload a hero image (optional). Click Save Theme.
- Product Manager: enter Name, Price, Description. Provide Image URL OR choose a File to upload. Click Add Product.
  - Drag product names in the admin list to reorder. Click Delete to remove.
- Video Manager: paste a YouTube embed URL (format: https://www.youtube.com/embed/VIDEO_ID) OR upload an MP4 to assets/videos/ and provide its relative path (or leave field blank and upload file via admin if you prefer).
  - Drag video titles in admin list to reorder. Click Delete to remove.
- Help: the Admin panel includes contextual help and instructions for users.
- Persistence: All changes are saved to your browser's LocalStorage. Clearing browser storage will remove them.

Deploying (quick):
- Netlify: drag & drop the project folder (or zip) into Netlify Drop. Or push to GitHub and connect Netlify.
- GitHub Pages: push the repository and enable Pages on main branch (use root as publish directory).
- Vercel: push to GitHub and import project in Vercel for automatic deploy.

Notes & next steps:
- This package is client-side only and stores data in the browser (LocalStorage). For production, integrate a backend for payments, user accounts, and persistent server storage.
- To accept payments: integrate Stripe/PayPal on a server. Ask me and I can provide a secure sample serverless function example.
